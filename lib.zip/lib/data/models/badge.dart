// TODO: badge model.
